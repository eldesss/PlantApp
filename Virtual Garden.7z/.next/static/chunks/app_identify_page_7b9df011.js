(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_identify_page_7b9df011.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_identify_page_7b9df011.js",
  "chunks": [
    "static/chunks/_8a4f1252._.js"
  ],
  "source": "dynamic"
});
