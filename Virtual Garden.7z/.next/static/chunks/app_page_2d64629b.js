(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_2d64629b.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_2d64629b.js",
  "chunks": [
    "static/chunks/app_page_00bddc8e.js"
  ],
  "source": "dynamic"
});
