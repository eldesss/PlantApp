(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_6580a1ed.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_6580a1ed.js",
  "chunks": [
    "static/chunks/app_9a417d46._.js"
  ],
  "source": "dynamic"
});
