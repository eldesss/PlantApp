(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_9fef97a3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_9fef97a3.js",
  "chunks": [
    "static/chunks/app_9a417d46._.js"
  ],
  "source": "dynamic"
});
