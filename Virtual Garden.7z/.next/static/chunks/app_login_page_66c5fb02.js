(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_66c5fb02.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_66c5fb02.js",
  "chunks": [
    "static/chunks/app_login_page_8cdfe95a.js"
  ],
  "source": "dynamic"
});
