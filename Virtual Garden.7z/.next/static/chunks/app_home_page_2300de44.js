(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_home_page_2300de44.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_home_page_2300de44.js",
  "chunks": [
    "static/chunks/app_home_page_464f5272.js"
  ],
  "source": "dynamic"
});
