(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_9fef97a3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_9fef97a3.js",
  "chunks": [
    "static/chunks/app_login_page_8cdfe95a.js"
  ],
  "source": "dynamic"
});
