(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_plants_page_105b05ce.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_plants_page_105b05ce.js",
  "chunks": [
    "static/chunks/node_modules_next_15251bc2._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/app_620d51ed._.js"
  ],
  "source": "dynamic"
});
