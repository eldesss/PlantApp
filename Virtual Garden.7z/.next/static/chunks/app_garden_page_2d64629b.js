(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_garden_page_2d64629b.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_garden_page_2d64629b.js",
  "chunks": [
    "static/chunks/node_modules_59b70099._.js",
    "static/chunks/app_garden_page_7918514c.js"
  ],
  "source": "dynamic"
});
