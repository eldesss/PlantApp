(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_garden_page_66efbd7a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_garden_page_66efbd7a.js",
  "chunks": [
    "static/chunks/node_modules_29ff943f._.js",
    "static/chunks/app_garden_page_7918514c.js"
  ],
  "source": "dynamic"
});
