(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_identify_page_105b05ce.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_identify_page_105b05ce.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_1f08d231._.js",
    "static/chunks/app_identify_page_ded6d4a4.js"
  ],
  "source": "dynamic"
});
