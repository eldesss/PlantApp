(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_identify_page_66efbd7a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_identify_page_66efbd7a.js",
  "chunks": [
    "static/chunks/node_modules_9fc440b8._.js",
    "static/chunks/app_identify_page_ded6d4a4.js"
  ],
  "source": "dynamic"
});
