(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_users_[id]_page_22ee2b75.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_users_[id]_page_22ee2b75.js",
  "chunks": [
    "static/chunks/_35d6285b._.js"
  ],
  "source": "dynamic"
});
