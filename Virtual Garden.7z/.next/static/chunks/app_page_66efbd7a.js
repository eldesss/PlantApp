(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_66efbd7a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_66efbd7a.js",
  "chunks": [
    "static/chunks/app_page_00bddc8e.js"
  ],
  "source": "dynamic"
});
