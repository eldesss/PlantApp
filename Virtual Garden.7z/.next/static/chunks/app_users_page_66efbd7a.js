(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_users_page_66efbd7a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_users_page_66efbd7a.js",
  "chunks": [
    "static/chunks/_c7f1a56f._.js"
  ],
  "source": "dynamic"
});
