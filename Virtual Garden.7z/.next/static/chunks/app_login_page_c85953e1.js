(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_c85953e1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_c85953e1.js",
  "chunks": [
    "static/chunks/_2f1b26ef._.js"
  ],
  "source": "dynamic"
});
