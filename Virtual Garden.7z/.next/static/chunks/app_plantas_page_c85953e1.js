(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_plantas_page_c85953e1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_plantas_page_c85953e1.js",
  "chunks": [
    "static/chunks/_53a7a7e3._.js"
  ],
  "source": "dynamic"
});
