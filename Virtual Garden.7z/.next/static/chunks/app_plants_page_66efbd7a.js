(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_plants_page_66efbd7a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_plants_page_66efbd7a.js",
  "chunks": [
    "static/chunks/node_modules_ff0a3535._.js",
    "static/chunks/app_bcd8f6c6._.js"
  ],
  "source": "dynamic"
});
