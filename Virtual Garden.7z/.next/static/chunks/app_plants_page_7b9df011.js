(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_plants_page_7b9df011.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_plants_page_7b9df011.js",
  "chunks": [
    "static/chunks/node_modules_59b70099._.js",
    "static/chunks/app_plants_page_b5132235.js"
  ],
  "source": "dynamic"
});
