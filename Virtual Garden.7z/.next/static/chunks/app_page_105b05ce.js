(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_105b05ce.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_105b05ce.js",
  "chunks": [
    "static/chunks/app_page_00bddc8e.js"
  ],
  "source": "dynamic"
});
